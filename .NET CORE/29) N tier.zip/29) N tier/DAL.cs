﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using myBO;
using Microsoft.Data.SqlClient;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace myDAL
{
    public class DAL
    {
        public bool saveData(BO b)
        {
            string data = JsonSerializer.Serialize(b);
            StreamWriter sw = null;
            try
            {
                sw = new StreamWriter("data.txt", append: true);
                sw.WriteLine(data);
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                sw.Close();
            }
            return true;
        }

        public List<string> getData()     //always return in the list of string.
        {
            List<string> list = new List<string>();
            StreamReader sr = null;
            try
            {
                sr = new StreamReader("data.txt");
                string data = sr.ReadLine();
                while(data!=null)
                {
                    list.Add(data);
                    data = sr.ReadLine();
                }
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                sr.Close();
            }
            return list;
        }
    }
}
