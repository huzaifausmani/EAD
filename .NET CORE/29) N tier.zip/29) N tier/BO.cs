﻿using System;
using System.Collections.Generic;
using System.Text;

namespace myBO
{
    public class BO
    {
        private static string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private static double salary;

        public double Salary
        {
            get { return salary; }
            set { salary = value; }
        }

        private static double tax;

        public double Tax
        {
            get { return tax; }
            set { tax = value; }
        }

        public override string ToString()
        {
            return $"{this.Name}\t\t{this.Salary}\t\t{this.Tax}";
        }
    }
}
