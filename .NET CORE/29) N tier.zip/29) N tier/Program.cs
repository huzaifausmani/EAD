﻿using System;
using myPL;

namespace Ntier_Practice
{
    class Program
    {
        static void Main(string[] args)
        {
            PL pl = new PL();
            pl.Interface();
        }
    }
}
