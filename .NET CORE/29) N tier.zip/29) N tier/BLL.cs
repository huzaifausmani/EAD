﻿using System;
using System.Collections.Generic;
using System.Text;
using myBO;
using myDAL;

namespace myBLL
{
    public class BLL
    {
        public bool saveData(BO b)
        {
            if(b.Salary<=10000)
            {
                b.Tax = 200;
            }
            else if(b.Salary>10000 && b.Salary<=20000)
            {
                b.Tax = 400;
            }
            else if (b.Salary > 20000 && b.Salary <= 30000)
            {
                b.Tax = 600;
            }
            else if(b.Salary > 30000 && b.Salary <= 50000)
            {
                b.Tax = 1000;
            }
            else
            {
                b.Tax = 1500;
            }
            DAL dal = new DAL();
            return dal.saveData(b);
        }

        public List<string> getData()
        {
            DAL dal = new DAL();
            return dal.getData();
        }
    }
}
