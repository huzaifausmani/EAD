﻿using System;
using System.Collections.Generic;
using System.Text;
using myBO;
using myBLL;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace myPL
{
    public class PL
    {
        public void Interface()
        {
            int choice;
            do
            {
                Console.WriteLine("\nEnter 1 to add data.");
                Console.WriteLine("Enter 2 to show data.");
                Console.WriteLine("Enter 0 to terminate.");
                Console.Write("Enter your choice: ");
                choice = int.Parse(Console.ReadLine());
                Console.WriteLine();
                if(choice==1)
                {
                    Console.Write("Enter your name: ");
                    string name = Console.ReadLine();
                    Console.Write("Enter your salary: ");
                    double sal = double.Parse(Console.ReadLine());

                    BO b = new BO { Name = name, Salary = sal };

                    BLL bll = new BLL();
                    bool check = bll.saveData(b);
                }
                else if(choice==2)
                {
                    BLL bll = new BLL();
                    List<string> list = bll.getData();
                    Console.WriteLine("Full Name\t\tSalary\t\tTax");
                    BO b = new BO();
                    foreach (string s in list)
                    {
                        b = JsonSerializer.Deserialize<BO>(s);
                        Console.WriteLine(b);
                    }
                }
                else if(choice==0)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Please enter correct choice.");
                }
            } while(choice != 0);
        }
    }
}
